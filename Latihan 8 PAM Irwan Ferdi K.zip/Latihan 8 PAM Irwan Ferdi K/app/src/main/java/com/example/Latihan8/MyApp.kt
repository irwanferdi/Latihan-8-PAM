package com.example.Latihan8

import android.app.Application
import androidx.room.Room

class MyApp : Application() {
    companion object {
        lateinit var database: AppDatabase
    }

    override fun onCreate() {
        super.onCreate()
        database = Room.databaseBuilder(
            this, AppDatabase::class.java, "my_database")
            .build()

        Thread {
            val userDao = database.userDao()
            userDao.insertUser(User(
                username = "Faisal Gaming", email = "faisal12@example.com"))
            userDao.insertUser(User(
                username = "Guntur", email = "guntur89@example.com"))
            userDao.insertUser(User(
                username = "Nasrul FG", email = "nasrulgg@example.com"))
        }.start()
    }
}